//
// Created by wt on 0017.
//

#ifndef SMARTCAR_CPPMAIN_H
#define SMARTCAR_CPPMAIN_H

#ifdef __cplusplus
extern "C" {
#endif

//初始化
void HeimaCarInit();

//机器人心脏跳动
void HeimaCarTick();

#ifdef __cplusplus
};
#endif


#endif //SMARTCAR_CPPMAIN_H
