//
// Created by wt on 0017.
//

#include "cppmain.h"


#include "Motor.h"
#include "Encoder.h"
#include "Wheel.h"
#include "Car.h"
#include "mylog.h"
#include <stdio.h>

//�Һ���
/*********************** �������� ***********************/
Motor motor(&htim8,TIM_CHANNEL_2,GPIOA,GPIO_PIN_4,GPIOA,GPIO_PIN_5,-1);
/*********************** ������ ***********************/
Encoder encoder(&htim3,TIM_CHANNEL_1|TIM_CHANNEL_2,1);
/*********************** Wheel���� ***********************/
Wheel wheel(motor,encoder);

//�����
/*********************** �������� ***********************/
Motor motor1(&htim8,TIM_CHANNEL_1,GPIOA,GPIO_PIN_2,GPIOA,GPIO_PIN_3,1);
/*********************** ������ ***********************/
Encoder encoder1(&htim2,TIM_CHANNEL_1|TIM_CHANNEL_2,-1);
/*********************** Wheel���� ***********************/
Wheel wheel1(motor1,encoder1);

/*********************** С�� ***********************/
Car car(wheel1,wheel);

void HeimaCarInit() {
//    log("hello init");
    /*********************** Motor��ʼ�� ***********************/
//    motor.init();
//    motor.spin(3000);
//    motor1.init();
//    motor1.spin(3000);
    /*********************** Encode��ʼ�� ***********************/
//    encoder.init();
//    encoder1.init();
    /*********************** ���ӳ�ʼ�� ***********************/
//    wheel.init();
//    //�����ٶ�
//    wheel.updateTargetVel(0.1);
    /*********************** ��ʼ��С�� ***********************/
    car.init();
    //С������
    car.updateSpeed(0.1,0.2);
}

void HeimaCarTick() {
    /*********************** ���ϸ����ٶ� ***********************/
//    wheel.spin();
    /*********************** ת�� ***********************/
//    motor.spin(3000);
    /*********************** ��ȡ�������� ***********************/
//    HAL_Delay(1000);
//    short i = encoder.read();
//    log("encode:%hd",i);
//    HAL_Delay(1000);
//    short i = encoder1.read();
//    mylog("encode:%hd",i);
    /*********************** С������ִ�� ***********************/
    car.spin();
    mylog("vel:%d  anguler:%d",(int)(car.getVel()*100),(int)(car.getAnguler()*100));
}
