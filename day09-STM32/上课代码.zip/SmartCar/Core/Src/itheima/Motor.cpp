//
// Created by wt on 0017.
//

#include "Motor.h"

Motor::Motor(TIM_HandleTypeDef *htim, uint32_t channel, GPIO_TypeDef *gpioA, uint16_t portA, GPIO_TypeDef *gpioB,
             uint16_t portB, int direction) {
    this->htim = htim;
    this->channel = channel;
    this->gpioA = gpioA;
    this->portA = portA;
    this->gpioB = gpioB;
    this->portB = portB;
    this->direction = direction;
}

Motor::~Motor() {

}

void Motor::init() {
    //������ʱ��
    HAL_TIM_PWM_Start(this->htim, this->channel);
    //���ﲻ�ᶯ(RESET SET)
    HAL_GPIO_WritePin(this->gpioA, this->portA, GPIO_PIN_RESET);
    HAL_GPIO_WritePin(this->gpioB, this->portB, GPIO_PIN_RESET);
}

void Motor::spin(int pwm) {
    //pwm�Ƿ��ڷ�Χ֮��
    if (pwm > MAX_PWM) {
        pwm = MAX_PWM;
    } else if (pwm < MIN_PWM) {
        pwm = MIN_PWM;
    }
    //����У��ϵ��
    pwm *= this->direction;
    //�жϷ���
    if (pwm > 0) {
        //ǰ
        HAL_GPIO_WritePin(gpioA, portA, GPIO_PIN_RESET);
        HAL_GPIO_WritePin(gpioB, portB, GPIO_PIN_SET);
    } else if (pwm < 0) {
        //��
        HAL_GPIO_WritePin(gpioA, portA, GPIO_PIN_SET);
        HAL_GPIO_WritePin(gpioB, portB, GPIO_PIN_RESET);
    } else {
        //ͣ����
        HAL_GPIO_WritePin(gpioA, portA, GPIO_PIN_RESET);
        HAL_GPIO_WritePin(gpioB, portB, GPIO_PIN_RESET);
    }
    //�ٶ�pwm
    __HAL_TIM_SET_COMPARE(this->htim, this->channel, abs(pwm));
}
