//
// Created by wt on 0016.
//

#ifndef STM32_CPPMAIN_H
#define STM32_CPPMAIN_H

#ifdef __cplusplus
extern "C" {
#endif

//ִ��һ��
void HeimaInit();

//���ִ��
void HeimaTick();

#ifdef __cplusplus
};
#endif

#endif //STM32_CPPMAIN_H
