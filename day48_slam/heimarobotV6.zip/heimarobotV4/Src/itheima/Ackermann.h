

#ifndef HEIMAROBOTV4_ACKERMANN_H
#define HEIMAROBOTV4_ACKERMANN_H

#include "Servo.h"
#include "Wheel.h"
/**
 * ������� �� һ�����
 */
class Ackermann {

public:
    Ackermann();
    ~Ackermann();

    Servo* servo;

    Wheel* wheel1;
    Wheel* wheel2;
    uint8_t carType = 0;

public:
    void init();
    void tick();

    void updateVel(float xVel,float yVel,float angularVel);
    void updatePID(float kp,float ki,float kd);
    float getXVel();
    float getYVel();
    float getAngularVel();

};


#endif //HEIMAROBOTV4_ACKERMANN_H
