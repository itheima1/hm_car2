#ifndef ZXCAR_ZET6_BATTERY_H
#define ZXCAR_ZET6_BATTERY_H

#include <stdio.h>

#ifdef __cplusplus
class Battery {
public:
    Battery(double minVoltage);
    ~Battery();

private:
    double minVoltage;
    double currentValue;

public:
    void init();

    bool isLowVoltage();

    double getVoltage();

    void measureVoltage();

    void resetMeasure();

};
#endif


#endif //ZXCAR_ZET6_BATTERY_H
