#ifndef ZXCAR_ZET6_BUZZER_H
#define ZXCAR_ZET6_BUZZER_H

#include "stm32f1xx_hal.h"

#ifdef __cplusplus

class Buzzer {

public:
    Buzzer(GPIO_TypeDef *port, uint16_t pin);

    ~Buzzer();

private:
    GPIO_TypeDef *port;
    uint16_t pin;

public:
    void open();

    void toggle();

    void close();

    bool isOpen();

};

#endif


#endif //ZXCAR_ZET6_BUZZER_H
